#!/usr/bin/env bash
HERE=$(cd $(dirname ${BASH_SOURCE[0]}) && pwd)
# Make Python Script Executable
chmod 755 $HERE/scroll_script/process_script.py
# Add location of Python Script To Path
export PATH=$HERE/scroll_script/process_script.py:$PATH
alias scrole=$HERE/scroll_script/process_script.py
