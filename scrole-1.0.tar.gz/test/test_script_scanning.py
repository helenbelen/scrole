import pytest
import os
from scroll_script.process_script import scan_script_for_variables, load_needed_variables, replace_scroll
import random

random.seed(3)
test_files = ["sample_script_1.sh","sample_script_2.sh","sample_script_3.sh"]
test_answers = ["sample_script_1_answer.txt","sample_script_2_answer.txt","sample_script_3_answer.txt"]
test_cases = dict(zip(test_files,test_answers))
TEST_SCROLL_FILE_PATH="test/test-files/test-scroll-file.txt"

# This test will confirm that the scan finds variables which are referenced before any kind
# of assignment ex. if [ -z ${MY_VARIABLE}] or variables that are used to assign values
# other variables before they have a value ex. second_var = ${FIRST_VARIABLE}
def test_scan_finds_unassigned_variables():
    test_file = random.choice(test_files)
    test_answer_file = open(os.path.join("test/test-files",test_cases[test_file]),"r")
    answer = test_answer_file.readline().strip("\n").split(",")
    test_answer_file.close()
    assert scan_script_for_variables(os.path.join("test/test-files",test_file)) == answer

def test_get_correct_needed_variables():
    if not os.environ.get("ENV_VAR"):
        os.environ["ENV_VAR"] = "GOTIT"

    script_variables = ["VAR_1","VAR_2","VAR_3","VAR_4","VAR_5","ENV_VAR"]
    scroll_variables = {"VAR_1":"value_1","VAR_2":"vaule_2"}
    ignore_variables = ["VAR_5"]
    assert load_needed_variables(script_variables,scroll_variables,ignore_variables) == {"VAR_3":"","VAR_4":""}

def test_dont_save_secrets():
    variables = {"my_key":"uehdklss","YOUR_TOKEN":"djsklfds","very_secret_thing":"98203jdlskl","normal_var":"helloworld"}
    replace_scroll(variables,TEST_SCROLL_FILE_PATH)
    scroll_file = open(TEST_SCROLL_FILE_PATH,"r")
    added = False
    for line in scroll_file:
        if line.upper().find("KEY") > 0 or line.upper().find("TOKEN") > 0 or line.upper().find("SECRET") > 0:
            added = True
            break;
    assert added == False
