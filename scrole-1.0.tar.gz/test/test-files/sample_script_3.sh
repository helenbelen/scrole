#! /bin/bash

SECRETS_DOCS_LINK='See https://drone-docs.us-central-1.core.k8s.tgt/02-advanced/secrets/'

: ${GARDENIA_TOKEN?"Gardenia token required. $SECRETS_DOCS_LINK"}
: ${GARDENIA_SERVER?"Gardenia token required. $SECRETS_DOCS_LINK"}

which gardenia 2>&1 > /dev/null

if [ $? -eq 1 ];
then
    echo "Gardenia not found on PATH. $SECRETS_DOCS_LINK"
    exit 1
fi

ORG_NAME=ole-acs

key_secret=`gopass ole-k8s/prod/object-store/ceph-secret-key`
if [ $? -ne 0 ];
then
    exit 2
fi

access_secret=`gopass ole-k8s/prod/object-store/ceph-access-key`
if [ $? -ne 0 ];
then
    exit 2
fi

TOSS_SECRET_KEY_NAME=toss_secret_key
echo "Writing secret to org ole-acs and name $TOSS_SECRET_KEY_NAME"
gardenia write org $ORG_NAME $TOSS_SECRET_KEY_NAME value=$key_secret

echo "Writing secret to org ole-acs and name $TOSS_SECRET_KEY_NAME"
TOSS_ACCESS_KEY_NAME=toss_access_key
gardenia write org $ORG_NAME $TOSS_ACCESS_KEY_NAME value=$access_secret
