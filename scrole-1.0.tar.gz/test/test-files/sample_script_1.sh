#!/bin/bash


echo "LOAD BALANCER DEPLOYMENT DISABLED FOR NOW!!!"

if [ -z "$APP_NAME" ]; then
  echo "Missing required parameter APP_NAME...exiting"
  exit 1
fi
app_name=$APP_NAME

if [ -z "${LOADBALANCER_NAME}" ]; then
  echo "Missing required parameter LOADBALANCER_NAME...exiting"
  exit 1
fi
loadbalancer_name=$LOADBALANCER_NAME

if [ -z "$NAMESPACE" ]; then
  echo "Missing required parameter NAMESPACE...exiting"
  exit 1
fi
namespace=$NAMESPACE

if [ -z "$APP_HTTP_PORT" ]; then
  echo "APP_HTTP_PORT not provided, defaulting to 8888"
  app_http_port=8888
else
  app_http_port=$APP_HTTP_PORT
fi

if [ -z "${LB_TEMPLATE_JSON_FILE}" ]; then
  echo "Missing required parameter LB_TEMPLATE_JSON_FILE...exiting"
  exit 1
elif [ ! -f $LB_TEMPLATE_JSON_FILE ]; then
  echo "Loadbalancer Json File $LB_TEMPLATE_JSON_FILE not found...exiting"
  exit 1
fi
lb_template_file=$LB_TEMPLATE_JSON_FILE

spinnakerGateUrl=$SPINNAKER_GATE_URL
echo "Using $spinnakerGateUrl"

echo "Starting Loadbalancer creation..."
echo ""

echo "------------------------------------"
echo ""
