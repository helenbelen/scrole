#!/usr/bin/env bash

docker_image_name=local_${APP_NAME}
 tapctl stop cluster  ${cluster_name} || \
    ./gradlew clean build distTar && \
    docker build . -t ${docker_image_name} &&  \
    tapctl start cluster ${cluster_name} -i ${docker_image_name}:latest  -e ${ENVIRONMENT} -p 5050
