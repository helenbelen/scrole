#!/usr/bin/env python
import os
import subprocess
import re
import sys, getopt
from os.path import expanduser
rx_dict = {
    'ignore_variables' : re.compile(r'(\w*=\$\w{1,})'),
    'common_variable' : re.compile(r'[${[A-z]*[}]'),
    'no_braces_variable': re.compile(r'(\$[A-z]{1,})'),
}

a_flag=False
# Variable in script that will be set
ignore_variables=[]
# Variables in scroll file
scroll_variables={}
# Variables which are needed and unset
needed_variables={}
# Variables which are needed and set
not_needed_variables={}
# variables from the script that the user wants to run
script_variables=[]
# variables set in your environment
env_variables={}

SCROLL_FILE_PATH= os.path.join(expanduser('~'),'.scrole')
SCRIPT_FILE=''
def check_scroll_file_exists():
    if (not os.path.isfile(SCROLL_FILE_PATH)) :
        scroll_file = open(SCROLL_FILE_PATH,"w")
        scroll_file.close()
    else :

        print("Scroll Files Exists...")
# TO DO: Ensure command enforcement. must have file, all is optional
def check_command_flags(argv):
    global a_flag
    global SCRIPT_FILE
    try:
        opts, args = getopt.getopt(argv,"hf:a",["help","file=","all"])

    except getopt.GetoptError:
        print ('Error Getting Ops')
        print('Valid flags are -f or --file and -a or --all. And file must have a value.')
        exit()
    if len(opts) == 0:
        print("usage: my_file.py -f [script_file]  (optional: -a or --all)")
        exit()
    else:
        for opt, arg in opts:

            if opt in ("-h","--help"):
                print("usage: my_file.py -f [script_file]  (optional: -a or --all)")
                exit()
            elif opt in ("-f","--file"):
                if a_flag:
                    print("usage: my_file.py -f [script_file]  (optional: -a or --all)")
                    exit()
                elif not os.path.isfile(arg):
                    print("Invalid File Name. Please enter an existing script file")
                    exit()
                SCRIPT_FILE = arg


            elif opt in ("-a","--all"):
                if len(SCRIPT_FILE) == 0:
                    check_scroll_file_exists()
                    print_scroll_file()
                    exit()

                a_flag=True

            else:
                print("usage: my_file.py -f [script_file]  (optional: -a or --all)")
                exit()
        check_scroll_file_exists()

def load_scroll_variables():
    scroll_file = open(SCROLL_FILE_PATH,"r")
    for line in scroll_file:
        pair = line.split(" ")[1].split("=")
        scroll_variables[pair[0]] = pair[1].strip()

def print_scroll_file():
    scroll_file = open(SCROLL_FILE_PATH,"r")
    for line in scroll_file:
        print(line)

def load_needed_variables(script_vars,scroll_vars,ignore_vars):
    for variable in script_vars:

        if variable not in scroll_vars and os.environ.get(variable) == None and variable not in ignore_vars:
            needed_variables[variable] = ""
        elif variable in scroll_vars and variable not in ignore_vars:
            not_needed_variables[variable] = scroll_vars[variable]
        elif os.environ.get(variable) and variable not in ignore_vars:
            env_variables[variable] = os.environ.get(variable)

    return needed_variables


def scan_script_for_variables(file_path) :
        global script_variables
        global ignore_variables

        script_file = open(file_path,"r")
        matches = [check_line_for_regex(line) for line in script_file]
        script_file.close()
        for key,match in matches:
            if match != None:

                match_text = match.group(0) # text that matched

                if key == "ignore_variables": # cases where local var is set to env variable
                    match_pair = match_text.split("=")
                    ignore_variables.append(match_pair[0])
                    script_variables.append(match_pair[1][1:])
                elif key == "common_variable":

                    temp = match_text.split("{")[1]
                    script_variables.append(temp.split("}")[0])
                else:

                    script_variables.append(match_text.split("$")[1])
        # Remove Duplicates

        script_variables = list(dict.fromkeys(script_variables))
        return script_variables

def check_line_for_regex(line):
    for key,rx in rx_dict.items():
        match = None
        match = rx.search(line)

        if match:
            return key, match

    return key,None

def prompt_user_all():
    global needed_variables
    global not_needed_variables
    if env_variables:
        print("==Variables already in environment : ==")
        for key,value in env_variables.items():
            print(key + "=" + value)
    if not_needed_variables:
        print("==Variables in scroll file : ==")
        for key, value in not_needed_variables.items():
            print(key + " = " + value)
    get_needed_variables(needed_variables)


def prompt_user():
    global needed_variables
    global not_needed_variables
    if env_variables:
        print ("==Variables already in environment : ==")
        for key,value in env_variables.items():
            print(key + "=" + value)
    if not_needed_variables:
        for key, value in not_needed_variables.items():
            print(key + " = " + value)
            while True:
                user_value = raw_input("Would you like to keep this value for  " + key + "(y/n)? : ")
                if user_value in ['y','Y']:
                    break
                elif user_value in ['n','N']:
                    new_user_value = raw_input("Please enter a value for " + key + " : ")
                    if len(new_user_value) > 0:
                        not_needed_variables[key] = new_user_value
                        break
                    else:
                        print("FAILURE: You must enter values for the needed variables to run the script. Try again")
                        exit()
                else:
                    print ("Please enter a single character for yes (y,Y) or no (n,N)")

        for key,value in not_needed_variables.items():
            replace_scroll(not_needed_variables,SCROLL_FILE_PATH)
    get_needed_variables(needed_variables)

def get_needed_variables(list):
    global not_needed_variables
    for key,value in list.items():
        user_value = raw_input("Please enter a value for " + key + " : ")
        if len(user_value) > 0:
            not_needed_variables[key] = user_value
            list[key] = user_value
        else:
            print("FAILURE: You must enter values for the needed variables to run the script. Try again")
            exit()
    for key,value in list.items():
        add_to_scroll(key,value,SCROLL_FILE_PATH)

def add_to_scroll(key, value,file_path):
    scroll_file = open(file_path,"a")
    if key.upper().find("KEY") < 0 and key.upper().find("TOKEN") < 0 and key.upper().find("SECRET") < 0 :
        scroll_file.write("export " + key +"="+value+"\n")
    else:
        print("Not saving " + key + "...")
    scroll_file.close()
    print(key + " has been added to the scroll value with the value of : " + value)

def replace_scroll(list,file_path):
    scroll_file = open(file_path,"w")
    for key, value in list.items():
        if key.upper().find("KEY") < 0 and key.upper().find("TOKEN") < 0 and key.upper().find("SECRET") < 0 :
            scroll_file.write("export " + key +"="+value+"\n")
        else:
            print("Not saving " + key + "...")
    scroll_file.close()

def run_script(set_vars,env_vars):
    command = ''
    for key,value in set_vars.items():
        command += key+"="+value+" "
    for key,value in env_vars.items():
        command += key+"="+value+" "
    command += "./"+SCRIPT_FILE
    print("Running...  " + command)
    os.system(command)


def main(argv):
    check_command_flags(argv)
    load_scroll_variables()
    scan_script_for_variables(SCRIPT_FILE)
    load_needed_variables(script_variables,scroll_variables,ignore_variables)
    if a_flag:
        prompt_user_all()
        while True:
            user_conf = raw_input("Do you want to run your script with these values ? [y,n]: ")
            if user_conf in ['y','Y']:
                print("Running ...")
                run_script(not_needed_variables,env_variables)
                exit()
            elif user_conf in ['n','N']:
                print("Exiting ...")
                exit()
            else:
                print("Invalid response. Please enter y/Y for Yes or n/N for No")

    else:
        prompt_user()
        run_script(not_needed_variables,env_variables)
if __name__=="__main__":
    main(sys.argv[1:])
